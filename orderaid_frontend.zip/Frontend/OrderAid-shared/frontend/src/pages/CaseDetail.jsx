
import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ArrowLeft,
  CheckCircle2,
  Clock3,
  FileText,
  ShieldCheck,
} from "lucide-react";
import { useApp } from "../context/useApp.js";
import StatusBadge from "../components/StatusBadge.jsx";

export default function CaseDetail() {
  const { caseId } = useParams();
  const { cases, updateCase } = useApp();
  const [notice, setNotice] = useState("");

  const currentCase = cases.find(
    (item) => item.case_id === caseId
  );

  if (!currentCase) {
    return (
      <section className="content-card">
        <h1>Case not found</h1>
        <p>
          This case isn't available in your current browser workspace.
        </p>
        <Link to="/cases" className="primary-button">
          Back to My Cases
        </Link>
      </section>
    );
  }

  function handleReview() {
    setNotice(
      "This is a demo review. No request has been submitted to the retailer."
    );
  }

  function handleMarkResolved() {
    updateCase({
      ...currentCase,
      status: "Resolved",
      updated_at: "Just now",
      demo: true,
    });

    setNotice(
      "Demo status updated locally. No retailer action was performed."
    );
  }

  return (
    <section className="case-detail-page">
      <Link to="/cases" className="back-link">
        <ArrowLeft size={16} />
        Back to My Cases
      </Link>

      <div className="page-header">
        <div>
          <p className="page-eyebrow">RESOLUTION PASSPORT</p>
          <h1>{currentCase.retailer} order issue</h1>
          <p className="page-description">
            Case {currentCase.case_id} · Order{" "}
            {currentCase.order_id || "not provided"}
          </p>
        </div>

        <StatusBadge status={currentCase.status} />
      </div>

      {currentCase.demo && (
        <div className="notice-banner">
          <ShieldCheck size={18} />
          <p>
            Demo record. Policy research and retailer submission have not
            been verified by a live backend.
          </p>
        </div>
      )}

      {notice && (
        <div className="notice-banner" role="status">
          <CheckCircle2 size={18} />
          <p>{notice}</p>
        </div>
      )}

      <div className="passport-grid">
        <article className="content-card passport-main">
          <div className="passport-section-heading">
            <span className="section-icon">
              <FileText size={19} />
            </span>
            <div>
              <h2>Case summary</h2>
              <p>Details provided for this order issue</p>
            </div>
          </div>

          <div className="passport-data">
            <div>
              <span>Retailer</span>
              <strong>{currentCase.retailer}</strong>
            </div>
            <div>
              <span>Item</span>
              <strong>{currentCase.item || "Not provided"}</strong>
            </div>
            <div>
              <span>Order amount</span>
              <strong>{currentCase.amount || "Not provided"}</strong>
            </div>
            <div>
              <span>Last updated</span>
              <strong>{currentCase.updated_at || "Not available"}</strong>
            </div>
          </div>

          <div className="passport-divider" />

          <h3>Reported issue</h3>
          <p className="passport-issue">
            {currentCase.issue || "No issue description provided."}
          </p>

          <div className="passport-divider" />

          <div className="passport-section-heading">
            <span className="section-icon">
              <ShieldCheck size={19} />
            </span>
            <div>
              <h2>Resolution request</h2>
              <p>Review before proceeding</p>
            </div>
          </div>

          <div className="draft-placeholder">
            <p>
              A resolution request will appear here after the investigation
              backend returns a verified draft.
            </p>
            <span>Draft not available in this demo record</span>
          </div>

          <button
            type="button"
            className="primary-button"
            onClick={handleReview}
            disabled={currentCase.status === "Resolved"}
          >
            Review request
          </button>
        </article>

        <aside className="content-card passport-sidebar">
          <div className="passport-section-heading">
            <span className="section-icon">
              <Clock3 size={19} />
            </span>
            <div>
              <h2>Resolution progress</h2>
              <p>Current case state</p>
            </div>
          </div>

          <div className="progress-timeline">
            <div className="timeline-step complete">
              <span />
              <div>
                <strong>Case created</strong>
                <p>Issue recorded in workspace</p>
              </div>
            </div>

            <div
              className={`timeline-step ${
                currentCase.status !== "Investigating" ? "complete" : ""
              }`}
            >
              <span />
              <div>
                <strong>Investigation</strong>
                <p>Policy research status not verified</p>
              </div>
            </div>

            <div
              className={`timeline-step ${
                currentCase.status === "Awaiting Approval" ||
                currentCase.status === "Resolved"
                  ? "complete"
                  : ""
              }`}
            >
              <span />
              <div>
                <strong>Approval</strong>
                <p>Requires review of the actual draft</p>
              </div>
            </div>

            <div
              className={`timeline-step ${
                currentCase.status === "Resolved" ? "complete" : ""
              }`}
            >
              <span />
              <div>
                <strong>Resolution</strong>
                <p>No retailer outcome has been verified</p>
              </div>
            </div>
          </div>

          <div className="passport-divider" />

          <h3>Policy references</h3>
          <p className="muted-copy">
            Official policy links will appear here when returned by the
            backend. No policy source is attached to this demo record.
          </p>

          {currentCase.status !== "Resolved" && (
            <button
              type="button"
              className="secondary-button"
              onClick={handleMarkResolved}
            >
              Mark resolved (demo)
            </button>
          )}
        </aside>
      </div>
    </section>
  );
}
